/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.shapetester1;

/**
 *
 * @author HelpTech
 */
public class ShapeTester1 {

    public static void main(String[] args) {
       Shape circle1 = new Circule("blue", true, 4.4);
        Shape circle2 = new Circule(3.5);

        Shape rectangle1 = new Rectangle("black", false, 2.0, 5.0);
        Shape rectangle2 = new Rectangle(2.0, 3.0);

        Shape square1 = new Square("white", true, 7.0);
        Rectangle square2 = new Square(8.0);

        System.out.println(circle1);
        System.out.println(circle2);
        System.out.println(rectangle1);
        System.out.println(rectangle2);
        System.out.println(square1);
        System.out.println(square2);

        System.out.println("Total number of shape : " + Shape.getShapeCount());
        System.out.println("Total number of circle: " + Circule.getCircleCount());
    }
}
