import java.util.ArrayList;

public class Tester {
    public static void main(String[] args) {
        Student[] studentsArray = new Student[2];
        Course Student1Module1 = new Course("PE", "Monday", "10:00", "Room 3", 85.0);
        Course Student1Module2 = new Course("Physics", "Wednesday", "10:00", "Room 5", 73.0);
        Course Student1Module3 = new Course("Biology", "Thursday", "10:00", "Room 2", 52.0);
        Course[] Student1Modules = { Student1Module1, Student1Module2, Student1Module3 };
        Student Student1 = new Student(1, "Lava", Student1Modules, "Engineering");

        Course Student2Module1 = new Course("PE", "Monday", "10:00", "Room 3", 95.0);
        Course Student2Module2 = new Course("Physics", "Wednesday", "10:00", "Room 5", 75.0);
        Course Student2Module3 = new Course("Biology", "Thursday", "10:00", "Room 2", 85.0);
        Course[] Student2Modules = { Student2Module1, Student2Module2, Student2Module3 };
        Student Student2 = new Student(1, "Sana", Student2Modules, "Engineering");
        studentsArray[0] = Student1;
        studentsArray[1] = Student2;
        ArrayList<Student> students = new ArrayList<Student>();
        students.add(studentsArray[0]);
        students.add(studentsArray[1]);
        for (Student student : students) {
            System.out.println(student);
        }
        studentsArray[0] = null;
        students.remove(0);
    }

}