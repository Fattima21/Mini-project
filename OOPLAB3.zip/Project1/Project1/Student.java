public class Student {
    private int sId;
    private String sName;
    private Course[] sModules = new Course[3];
    private double sAverage;
    private String sProgram;

    public Student(int sId, String sName, Course[] sModules, String sProgram) {
        this.sId = sId;
        this.sName = sName;
        this.sModules = sModules;
        this.sAverage = calcAverage();
        this.sProgram = sProgram;
    }

    public int getsId() {
        return sId;
    }

    public void setsId(int sId) {
        this.sId = sId;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public Course[] getsModules() {
        return sModules;
    }

    public void setsModules(Course[] sModules) {
        this.sModules = sModules;
    }

    public double getsAverage() {
        return sAverage;
    }

    public void setsAverage(double sAverage) {
        this.sAverage = sAverage;
    }

    public String getsProgram() {
        return sProgram;
    }

    public void setsProgram(String sProgram) {
        this.sProgram = sProgram;
    }

    public double calcAverage() {
        double total = 0;
        for (Course mark : sModules) {
            total += mark.geteMark();
        }
        return total / 3;
    }

    @Override
    public String toString() {
        return "{" +
                " sId='" + getsId() + "'" +
                ", sName='" + getsName() + "'" +
                ", sAverage='" + getsAverage() + "'" +
                "}";
    }
}